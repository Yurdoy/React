import { useEffect } from "react"

function Posts(props) {
    const {count} = props


    function helloWorl() {

    }
    useEffect(()=> {
        console.log('этот лог вы видите потому что оно вызвалось после рендера компонента')
        console.log('ну или оно зависит от какого то состояния');
    }, [])
    return (
        <div>
            Count: {count}
        </div>
    )
}

export default Posts