import { useEffect, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Posts from './components/Posts'
import axios from 'axios'

function App() {
  const [count, setCount] = useState(10)
  const [isShow, setIsShow] = useState(false)
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  //&& логический оператор И возвращет true в том случае когда два операнда (элемент слева и права от И) равны true
  // console.log(true && true)
  useEffect(() => {
    console.log('hello world ');
    axios.get('https://jsonplaceholder.typicode.com/posts')
    .then(res => {
      console.log(res)
    })
  }, [isShow])  
  useEffect(() => {
    if(username.length > 5 && password.length > 3) {
      console.log({
        username, password
      })
    }
  }, [username, password])
  return (
    <>
      {/* <Posts count={count} setCount={setCount}/>
      <button onClick={() => setCount(count + 1 )}>increase</button>
      {
        isShow && <div>This component gonna work only in special condition</div> 
      }
      <button onClick={() => setIsShow(!isShow)}>click to change condition</button> */}
      <input type="text" value={username} onChange={(e) => setUsername(e.target.value) } />
      <input type="text" value={password} onChange={(e) => setPassword(e.target.value) } />
      
    </>
  )
}

export default App
